package me.technick6425.tafobot;

public class Main {
	public static void main(String[] args) {
		new TafoBot();
	}
}
